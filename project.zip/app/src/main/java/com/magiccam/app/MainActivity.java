package com.magiccam.app;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.camera2.CaptureRequest;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Size;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.camera2.interop.Camera2CameraControl;
import androidx.camera.camera2.interop.CaptureRequestOptions;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FallbackStrategy;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int IDLE = 0, REC = 1, PAUSED = 2;
    private static final int REQ = 7;

    private PreviewView previewView;
    private ImageView ghost, thumb;
    private TextView timeChip, countText, hint, chipGhost, chipGrid, chipTimer, chipMic, chipLock, chipFlip, doneBtn, opacityLabel;
    private View gridView, opacityRow;
    private RecordButton recBtn;
    private SeekBar opacity;

    private ProcessCameraProvider provider;
    private Camera camera;
    private VideoCapture<Recorder> videoCapture;
    private Recording recording;

    private int state = IDLE, timerSec = 3, lens = CameraSelector.LENS_FACING_BACK;
    private boolean ghostOn = true, gridOn = false, micOn = true, aeLocked = false, counting = false;
    private Uri lastUri;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.preview);
        ghost = findViewById(R.id.ghost);
        thumb = findViewById(R.id.thumb);
        timeChip = findViewById(R.id.timeChip);
        countText = findViewById(R.id.countText);
        hint = findViewById(R.id.hint);
        chipGhost = findViewById(R.id.chipGhost);
        chipGrid = findViewById(R.id.chipGrid);
        chipTimer = findViewById(R.id.chipTimer);
        chipMic = findViewById(R.id.chipMic);
        chipLock = findViewById(R.id.chipLock);
        chipFlip = findViewById(R.id.chipFlip);
        doneBtn = findViewById(R.id.doneBtn);
        opacityLabel = findViewById(R.id.opacityLabel);
        gridView = findViewById(R.id.grid);
        opacityRow = findViewById(R.id.opacityRow);
        recBtn = findViewById(R.id.recBtn);
        opacity = findViewById(R.id.opacity);

        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FIT_CENTER);
        ghost.setAlpha(0.4f);

        recBtn.setOnClickListener(v -> onRecordTap());
        doneBtn.setOnClickListener(v -> onDone());
        thumb.setOnClickListener(v -> openLast());

        chipGhost.setOnClickListener(v -> {
            ghostOn = !ghostOn;
            if (state == PAUSED) ghost.setVisibility(ghostOn && ghost.getDrawable() != null ? View.VISIBLE : View.GONE);
            updateChips();
        });
        chipGrid.setOnClickListener(v -> {
            gridOn = !gridOn;
            gridView.setVisibility(gridOn ? View.VISIBLE : View.GONE);
            updateChips();
        });
        chipTimer.setOnClickListener(v -> {
            timerSec = timerSec == 0 ? 3 : timerSec == 3 ? 5 : timerSec == 5 ? 10 : 0;
            updateChips();
        });
        chipMic.setOnClickListener(v -> {
            if (state != IDLE) { toast("Change sound before you start recording"); return; }
            micOn = !micOn;
            updateChips();
        });
        chipLock.setOnClickListener(v -> toggleLock());
        chipFlip.setOnClickListener(v -> {
            if (state != IDLE) { toast("Flip the camera before you start recording"); return; }
            lens = lens == CameraSelector.LENS_FACING_BACK ? CameraSelector.LENS_FACING_FRONT : CameraSelector.LENS_FACING_BACK;
            bind();
        });

        opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                int v = Math.max(10, p);
                ghost.setAlpha(v / 100f);
                opacityLabel.setText(v + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        previewView.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_UP && camera != null && !aeLocked) {
                MeteringPoint p = previewView.getMeteringPointFactory().createPoint(ev.getX(), ev.getY());
                camera.getCameraControl().startFocusAndMetering(new FocusMeteringAction.Builder(p).build());
                v.performClick();
            }
            return true;
        });

        updateChips();
        updateUi();

        if (granted(Manifest.permission.CAMERA)) startCamera();
        else ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQ);
    }

    private boolean granted(String p) {
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (granted(Manifest.permission.CAMERA)) startCamera();
        else toast("Camera permission is needed");
        if (!granted(Manifest.permission.RECORD_AUDIO)) { micOn = false; updateChips(); }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            try {
                provider = f.get();
                bind();
            } catch (Exception e) {
                toast("Camera error: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @SuppressWarnings("deprecation")
    private void bind() {
        if (provider == null) return;
        try {
            Preview preview = new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_16_9).build();
            preview.setSurfaceProvider(previewView.getSurfaceProvider());
            Recorder recorder = new Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)))
                    .build();
            videoCapture = VideoCapture.withOutput(recorder);
            CameraSelector sel = new CameraSelector.Builder().requireLensFacing(lens).build();
            provider.unbindAll();
            camera = provider.bindToLifecycle(this, sel, preview, videoCapture);
            aeLocked = false;
            updateChips();
        } catch (Exception e) {
            toast("Camera error: " + e.getMessage());
        }
    }

    private void onRecordTap() {
        if (counting || videoCapture == null) return;
        if (state == IDLE) {
            ghost.setVisibility(View.GONE);
            countdown(this::startRecording);
        } else if (state == REC) {
            if (recording != null) recording.pause();
            state = PAUSED;
            Bitmap bmp = previewView.getBitmap();
            if (bmp != null) ghost.setImageBitmap(bmp);
            ghost.setVisibility(ghostOn && bmp != null ? View.VISIBLE : View.GONE);
            updateUi();
        } else {
            countdown(() -> {
                if (recording != null) recording.resume();
                state = REC;
                ghost.setVisibility(View.GONE);
                updateUi();
            });
        }
    }

    private void countdown(Runnable done) {
        if (timerSec == 0) { done.run(); return; }
        counting = true;
        updateUi();
        final int[] n = {timerSec};
        countText.setText(String.valueOf(n[0]));
        countText.setVisibility(View.VISIBLE);
        h.postDelayed(new Runnable() {
            @Override public void run() {
                n[0]--;
                if (n[0] <= 0) {
                    countText.setVisibility(View.GONE);
                    counting = false;
                    done.run();
                    updateUi();
                } else {
                    countText.setText(String.valueOf(n[0]));
                    h.postDelayed(this, 1000);
                }
            }
        }, 1000);
    }

    @SuppressWarnings("MissingPermission")
    private void startRecording() {
        try {
            String name = "MagicCam_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MagicCam");
            MediaStoreOutputOptions opts = new MediaStoreOutputOptions.Builder(
                    getContentResolver(), MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                    .setContentValues(cv).build();
            PendingRecording pr = videoCapture.getOutput().prepareRecording(this, opts);
            if (micOn && granted(Manifest.permission.RECORD_AUDIO)) pr = pr.withAudioEnabled();
            recording = pr.start(ContextCompat.getMainExecutor(this), this::onEvent);
            state = REC;
            updateUi();
        } catch (Exception e) {
            toast("Could not start: " + e.getMessage());
            state = IDLE;
            updateUi();
        }
    }

    private void onEvent(VideoRecordEvent e) {
        if (e instanceof VideoRecordEvent.Finalize) {
            VideoRecordEvent.Finalize f = (VideoRecordEvent.Finalize) e;
            Uri u = f.getOutputResults().getOutputUri();
            boolean hasFile = u != null && !Uri.EMPTY.equals(u);
            if (f.getError() == VideoRecordEvent.Finalize.ERROR_NONE || hasFile) {
                lastUri = u;
                toast("Saved to Gallery: Movies/MagicCam");
                loadThumb();
            } else {
                toast("Save failed (error " + f.getError() + ")");
            }
            recording = null;
            state = IDLE;
            ghost.setVisibility(View.GONE);
            timeChip.setText("00:00");
            updateUi();
        } else {
            long s = e.getRecordingStats().getRecordedDurationNanos() / 1_000_000_000L;
            timeChip.setText(String.format(Locale.US, "%02d:%02d", s / 60, s % 60));
        }
    }

    private void onDone() {
        if (state == IDLE || counting) return;
        if (recording != null) recording.stop();
        ghost.setVisibility(View.GONE);
    }

    private void toggleLock() {
        if (camera == null) return;
        aeLocked = !aeLocked;
        try {
            Camera2CameraControl.from(camera.getCameraControl()).setCaptureRequestOptions(
                    new CaptureRequestOptions.Builder()
                            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_LOCK, aeLocked)
                            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, aeLocked)
                            .build());
            toast(aeLocked ? "Brightness & colour locked" : "Auto brightness");
        } catch (Exception ex) {
            aeLocked = false;
            toast("Lock not supported on this phone");
        }
        updateChips();
    }

    private void loadThumb() {
        final Uri u = lastUri;
        if (u == null) return;
        new Thread(() -> {
            try {
                Bitmap bmp = getContentResolver().loadThumbnail(u, new Size(200, 200), null);
                runOnUiThread(() -> { thumb.setImageBitmap(bmp); thumb.setVisibility(View.VISIBLE); });
            } catch (Exception ignored) {
                runOnUiThread(() -> thumb.setVisibility(View.VISIBLE));
            }
        }).start();
    }

    private void openLast() {
        if (lastUri == null) return;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(lastUri, "video/mp4");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            toast("Open it from your Gallery: Movies/MagicCam");
        }
    }

    private void setChip(TextView t, boolean on) {
        t.setBackgroundResource(on ? R.drawable.chip_on : R.drawable.chip_off);
        t.setTextColor(on ? 0xFF111111 : 0xFFFFFFFF);
    }

    private void updateChips() {
        setChip(chipGhost, ghostOn);
        setChip(chipGrid, gridOn);
        setChip(chipTimer, timerSec > 0);
        chipTimer.setText(timerSec > 0 ? "Timer " + timerSec + "s" : "Timer off");
        setChip(chipMic, micOn);
        chipMic.setText(micOn ? "Sound on" : "Sound off");
        setChip(chipLock, aeLocked);
        setChip(chipFlip, false);
    }

    private void updateUi() {
        recBtn.setState(state);
        boolean active = state != IDLE;
        doneBtn.setAlpha(active && !counting ? 1f : 0.3f);
        chipFlip.setAlpha(active ? 0.4f : 1f);
        chipMic.setAlpha(active ? 0.4f : 1f);
        opacityRow.setVisibility(state == PAUSED ? View.VISIBLE : View.INVISIBLE);
        timeChip.setBackgroundResource(state == REC ? R.drawable.chip_rec : state == PAUSED ? R.drawable.chip_pause : R.drawable.chip_off);
        timeChip.setTextColor(state == PAUSED ? 0xFF111111 : 0xFFFFFFFF);
        if (counting) hint.setText("Get ready…");
        else if (state == IDLE) hint.setText("Tap the red button to start");
        else if (state == REC) hint.setText("Recording · tap to pause");
        else hint.setText("Paused · line up with the ghost, then tap to continue");
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
