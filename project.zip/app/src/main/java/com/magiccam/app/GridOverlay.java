package com.magiccam.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class GridOverlay extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GridOverlay(Context c, AttributeSet a) {
        super(c, a);
        p.setColor(0x66FFFFFF);
        p.setStrokeWidth(2f);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        for (int i = 1; i <= 2; i++) {
            c.drawLine(w * i / 3f, 0, w * i / 3f, h, p);
            c.drawLine(0, h * i / 3f, w, h * i / 3f, p);
        }
    }
}
