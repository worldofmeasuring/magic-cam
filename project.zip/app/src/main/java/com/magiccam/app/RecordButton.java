package com.magiccam.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class RecordButton extends View {
    private int state = 0;
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);

    public RecordButton(Context c, AttributeSet a) {
        super(c, a);
        ring.setStyle(Paint.Style.STROKE);
        fill.setColor(0xFFFF2D55);
        bar.setColor(Color.WHITE);
        setClickable(true);
    }

    public void setState(int s) {
        state = s;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f;
        float sw = r * 0.11f;
        ring.setStrokeWidth(sw);
        ring.setColor(state == 2 ? 0xFFFFD60A : Color.WHITE);
        c.drawCircle(cx, cy, r - sw / 2f, ring);
        if (state == 1) {
            // recording: red rounded square with pause bars
            float s = r * 0.46f;
            c.drawRoundRect(cx - s, cy - s, cx + s, cy + s, r * 0.18f, r * 0.18f, fill);
            float bw = s * 0.26f, bh = s * 0.95f, gap = s * 0.22f;
            c.drawRoundRect(cx - gap - bw, cy - bh / 2f, cx - gap, cy + bh / 2f, bw / 3f, bw / 3f, bar);
            c.drawRoundRect(cx + gap, cy - bh / 2f, cx + gap + bw, cy + bh / 2f, bw / 3f, bw / 3f, bar);
        } else {
            c.drawCircle(cx, cy, r * 0.74f, fill);
        }
    }
}
